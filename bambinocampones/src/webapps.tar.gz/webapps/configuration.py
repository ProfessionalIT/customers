#!/usr/bin/python
# -*- coding: utf-8 -*-
# Database Connection variables
DBN = 'sqlite'
HOST = 'localhost'
DB = 'luis_website'
USER = 'luis'
MODE = 'development'  # production or development
PWD = 'Master12131415'
# Generic configuration website variables
WEBSITE_URL = 'http://www.bambinocampones.com.br'
WEBSITE_NAME = 'Escola de Educação Infantil em Canoas - RS'
ADMIN_VERSION = '001a'
